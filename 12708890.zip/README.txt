﻿***Data set of multi-source dermatoscopic images of skin hair for skin lesions***
Author: Gallucci, A. (Alessio)
TU Eindhoven, Department of Mathematics and Computer Science
orcid: https://orcid.org/0000-0002-6758-8131
email: a.gallucci@tue.nl, alessio.gallucci@gmail.com

***General Introduction***
Most of the research to detect and classify skin conditions does not analyze how the presence of skin hair occlusions may affect diagnosis. Multiple works are trying to detect and classify skin conditions. None of them analyzes how the presence of skin hair occlusion may affect the prediction. In this work, we first trained a neural network to segment skin hair. Then , building on this knowledge, we tested whether the presence of hair affects the skin lesion detection using four different augmentation strategies. The analysis proves that shaving before image-based skin lesion assessment is not necessary.

***Purpose of the test campaign***
The purpose of these experiments was to investigate the Implication of skin hair on diagnosis of microscopic skin lesions.

***Description of the data in this data set***
This dataset contains data collected during the above analysis. We contribute to the enrichment of the public benchmark dataset HAM10000 [1] by annotating skin hair of 75 random images. The 75 images are first resized to 608x480 and then the hair hair predicted using state-of-the-art architecture for biomedical segmentation U-NET [2]. The filename uniquely identify the lesion in HAM10000.

[1] P. Tschandl, C. Rosendahl, and H. Kittler, “The HAM10000 dataset, a large collection of multi-source dermatoscopic images of common pigmented skin lesions,” Sci. data, vol. 5, p. 180161, 2018.
[2] O. Ronneberger, P. Fischer, and T. Brox, “U-net: Convolutional networks for biomedical image segmentation,” in International Conference on Medical image computing and computer-assisted intervention, 2015, pp. 234–241.
